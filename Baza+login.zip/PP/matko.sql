-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2022 at 04:16 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `matko`
--

-- --------------------------------------------------------

--
-- Table structure for table `bodoviispit`
--

CREATE TABLE `bodoviispit` (
  `bodoviIspitID` int(255) NOT NULL,
  `ispitID` int(255) NOT NULL,
  `ucenikID` int(255) NOT NULL,
  `roditeljID` int(255) NOT NULL,
  `brojBodova` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bodoviizazov`
--

CREATE TABLE `bodoviizazov` (
  `bodoviID` int(255) NOT NULL,
  `izazovID` int(255) NOT NULL,
  `ucenikID` int(255) NOT NULL,
  `roditeljID` int(255) NOT NULL,
  `brojBodova` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dnevniizazov`
--

CREATE TABLE `dnevniizazov` (
  `izazovID` int(255) NOT NULL,
  `ucenikID` int(255) NOT NULL,
  `brojBodova` int(255) NOT NULL,
  `datumIzazova` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ispit`
--

CREATE TABLE `ispit` (
  `ispitID` int(255) NOT NULL,
  `ucenikID` int(255) NOT NULL,
  `datumIspita` date NOT NULL DEFAULT current_timestamp(),
  `brojBodova` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roditelj`
--

CREATE TABLE `roditelj` (
  `roditeljID` int(255) NOT NULL,
  `ucenikID` int(255) NOT NULL,
  `ime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prezime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `e-mail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sifra` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datumUpisa` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ucenik`
--

CREATE TABLE `ucenik` (
  `ucenikID` int(255) NOT NULL,
  `ime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prezime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `e-mail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sifra` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datumUpisa` date NOT NULL DEFAULT current_timestamp(),
  `nazivSkole` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bodoviispit`
--
ALTER TABLE `bodoviispit`
  ADD PRIMARY KEY (`bodoviIspitID`),
  ADD UNIQUE KEY `ispitID` (`ispitID`),
  ADD UNIQUE KEY `roditeljID` (`roditeljID`),
  ADD UNIQUE KEY `ucenikID` (`ucenikID`);

--
-- Indexes for table `bodoviizazov`
--
ALTER TABLE `bodoviizazov`
  ADD PRIMARY KEY (`bodoviID`),
  ADD UNIQUE KEY `izazovID` (`izazovID`),
  ADD UNIQUE KEY `ucenikID` (`ucenikID`),
  ADD UNIQUE KEY `roditeljID` (`roditeljID`);

--
-- Indexes for table `dnevniizazov`
--
ALTER TABLE `dnevniizazov`
  ADD PRIMARY KEY (`izazovID`),
  ADD UNIQUE KEY `ucenikID` (`ucenikID`);

--
-- Indexes for table `ispit`
--
ALTER TABLE `ispit`
  ADD PRIMARY KEY (`ispitID`),
  ADD UNIQUE KEY `ucenikID` (`ucenikID`);

--
-- Indexes for table `roditelj`
--
ALTER TABLE `roditelj`
  ADD PRIMARY KEY (`roditeljID`),
  ADD UNIQUE KEY `ucenikID` (`ucenikID`),
  ADD UNIQUE KEY `e-mail` (`e-mail`);

--
-- Indexes for table `ucenik`
--
ALTER TABLE `ucenik`
  ADD PRIMARY KEY (`ucenikID`),
  ADD UNIQUE KEY `e-mail` (`e-mail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bodoviispit`
--
ALTER TABLE `bodoviispit`
  MODIFY `bodoviIspitID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bodoviizazov`
--
ALTER TABLE `bodoviizazov`
  MODIFY `bodoviID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dnevniizazov`
--
ALTER TABLE `dnevniizazov`
  MODIFY `izazovID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ispit`
--
ALTER TABLE `ispit`
  MODIFY `ispitID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roditelj`
--
ALTER TABLE `roditelj`
  MODIFY `roditeljID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ucenik`
--
ALTER TABLE `ucenik`
  MODIFY `ucenikID` int(255) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bodoviispit`
--
ALTER TABLE `bodoviispit`
  ADD CONSTRAINT `bodoviispit_ibfk_1` FOREIGN KEY (`ispitID`) REFERENCES `ispit` (`ispitID`),
  ADD CONSTRAINT `bodoviispit_ibfk_2` FOREIGN KEY (`roditeljID`) REFERENCES `roditelj` (`roditeljID`),
  ADD CONSTRAINT `bodoviispit_ibfk_3` FOREIGN KEY (`ucenikID`) REFERENCES `ucenik` (`ucenikID`);

--
-- Constraints for table `bodoviizazov`
--
ALTER TABLE `bodoviizazov`
  ADD CONSTRAINT `bodoviizazov_ibfk_1` FOREIGN KEY (`izazovID`) REFERENCES `dnevniizazov` (`izazovID`),
  ADD CONSTRAINT `bodoviizazov_ibfk_2` FOREIGN KEY (`roditeljID`) REFERENCES `roditelj` (`roditeljID`),
  ADD CONSTRAINT `bodoviizazov_ibfk_3` FOREIGN KEY (`ucenikID`) REFERENCES `ucenik` (`ucenikID`);

--
-- Constraints for table `dnevniizazov`
--
ALTER TABLE `dnevniizazov`
  ADD CONSTRAINT `dnevniizazov_ibfk_1` FOREIGN KEY (`ucenikID`) REFERENCES `ucenik` (`ucenikID`);

--
-- Constraints for table `ispit`
--
ALTER TABLE `ispit`
  ADD CONSTRAINT `ispit_ibfk_1` FOREIGN KEY (`ucenikID`) REFERENCES `ucenik` (`ucenikID`);

--
-- Constraints for table `roditelj`
--
ALTER TABLE `roditelj`
  ADD CONSTRAINT `roditelj_ibfk_1` FOREIGN KEY (`ucenikID`) REFERENCES `ucenik` (`ucenikID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
