<?php
echo "Statistika rješavanja";
<break>

echo "Dnevna statistika";
<break>
echo "Dnevni izazov";
<break>
echo "Zadaci za vježbu"
<break>
?>