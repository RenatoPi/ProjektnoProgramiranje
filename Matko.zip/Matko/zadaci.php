<?php
function tezina(){

}

function zbrajanje($num1, $num2){
   $zbroj=$num1+$num2
   echo $num1 "+" $num2 "=" $zbroj
};

function oduzimanje($num1, $num2){
    $rezultat=$num1-$num2
    echo $num1 "-" $num2 "=" $rezultat
};

function mnozenje($num1, $num2){
    $umnozak=$num1*$num2
    echo $num1 "*" $num2 "=" $umnozak;
};

function dijeljenje($num1,$num2){
    for(int i; i<20; i++){
    $kolicnik=$num1/$num2
    echo $num1 "/" $num2 "=" "kolicnik";}

};

$num1= (rand(10,100));
$num2= (rand(0,10));

echo "izaberite gradivo";
switch():
    case Zbrajanje:
        echo zbrajanje;
    case Oduzimanje:
        echo oduzimanje;
    case Mnozenje:
        echo mnozenje;
    case Dijeljenje:
        echo dijeljenje;
    default:
    echo "Nije odabrano gradivo"


?>